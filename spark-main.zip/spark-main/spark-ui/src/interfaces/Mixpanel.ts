export enum MixpanelEvents {
  SparkAppInitilized = "Spark App initilized",
  SqlSummarySelected = "Sql Summary Selected",
  KeepAlive = "Keep Alive",
}
