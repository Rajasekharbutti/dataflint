export type StagesRdd = Record<string, Record<string, string>>;
